package roberta.heartbeepapp;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;

public class WearableViewPagerAdapter extends FragmentStatePagerAdapter {

    ArrayList<String> data;

    public WearableViewPagerAdapter(FragmentManager fm, ArrayList<String> data) {
        super(fm);

        this.data = data;
    }

    @Override
    public Fragment getItem(int i) {
        return WearableDataFragment.newInstance(data.get(i));
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return data.get(position);
    }
}
