package roberta.heartbeepapp;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.db.williamchart.view.LineChartView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.threeten.bp.LocalDate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class WearableDataFragment extends Fragment {

    public static final String ARG_WEAR_ID = "ARG_WEAR_ID";
    public static final int WEEK_SIZE = 7;

    private String wearId;
    private LinkedHashMap<String, Float> weekAverageValues;

    public static WearableDataFragment newInstance(String wearId){
        WearableDataFragment fragment = new WearableDataFragment();
        Bundle b = new Bundle();
        b.putString(ARG_WEAR_ID, wearId);
        fragment.setArguments(b);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        wearId = getArguments().getString(ARG_WEAR_ID);

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_wearable_data, container, false);
    }

    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Log.d("WearId", wearId);

        getWeekData(view, LocalDate.now(), true, WEEK_SIZE);
    }

    private void getWeekData(final View view, LocalDate date, final boolean currentWeek, final int requiredDates) {
        FirebaseDatabase.getInstance().getReference("users")
                .child("wear")
                .child(wearId)
                .child("data")
                .child(Utils.getWeekStart(date).toString())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Map<String, Object> wd = (Map<String,Object>) dataSnapshot.getValue();

                        if(wd == null || wd.isEmpty()){
                            return;
                        }

                        ArrayList<Map.Entry<String, Object>> weekData = new ArrayList<>(wd.entrySet());

                        weekData = weekDataDescendingSort(weekData);

                        if(currentWeek)
                            weekAverageValues = new LinkedHashMap<>();

                        int weekLength = requiredDates;
                        if(weekData.size() < weekLength)
                            weekLength = weekData.size();

                        for(int index = 0; index < weekLength; index++) {
                            Map.Entry<String, Object>entry = weekData.get(index);

                            //separated days of the week
                            Map<String, Object> values = (Map<String, Object>) entry.getValue();

                            weekAverageValues.put(entry.getKey(), calculateAverage(values));
                            Log.e("WeekData", entry.getKey() +" " + calculateAverage(values));
                        }

                        if(currentWeek && weekAverageValues.size() < WEEK_SIZE){
                            getWeekData(view, LocalDate.now().minusWeeks(1), false, WEEK_SIZE - weekAverageValues.size());
                        }else{
                            updateGraph(view);
                        }

                        showEmptyPage(view, weekAverageValues.isEmpty());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }

    private void updateGraph(View view) {
        Log.e("UpdateGraph", "True");
        LineChartView chart = view.findViewById(R.id.lineChart);
        chart.setGradientFillColors(new int[]{Color.parseColor("#81000000"), Color.TRANSPARENT});
        chart.getAnimation().setDuration(1000);
        chart.animate(weekAverageValues);

    }

    private float calculateAverage(Map<String, Object> values) {
        long sum = 0;
        for(Map.Entry<String, Object>entry: values.entrySet()) {
            sum += (long)entry.getValue();
        }

        return (float)sum/values.size();
    }

    private void showEmptyPage(View v, Boolean show){
        if(!show) {
            v.findViewById(R.id.lineChart).setVisibility(View.VISIBLE);
        }else{
            v.findViewById(R.id.lineChart).setVisibility(View.GONE);
        }
    }


    private ArrayList<Map.Entry<String, Object>> weekDataDescendingSort(ArrayList<Map.Entry<String, Object>> wd){
        ArrayList<Map.Entry<String, Object>> result = wd;

        for(int i = 0; i < result.size() - 1; i++){
            for(int j = i + 1; j < result.size(); j++){
                if(result.get(j).getKey().compareToIgnoreCase(result.get(i).getKey()) >= 0){
                    Map.Entry<String, Object> temp = result.get(i);
                    result.set(i, result.get(j));
                    result.set(j, temp);
                }
            }
        }


        return result;
    }

    private int measureHeartRisk(ArrayList<HeartRateValueEntity> data){
        //sort data
        quickSort(data, 0, data.size() - 1);
        for(int i = 0; i < data.size(); i++){
            Log.e("Data", data.get(i).getDate() + " " + data.get(i).getValue());
        }

        //q1
        //findMedian(data, 0, data.)

        return 0;
    }

    private void quickSort(ArrayList<HeartRateValueEntity> data, int leftMostIndex, int rightMostIndex){
        if(leftMostIndex >= rightMostIndex){
            return;
        }

        HeartRateValueEntity selected = data.get(rightMostIndex);

        int split = leftMostIndex;

        for(int index = leftMostIndex; index <= rightMostIndex; index++){
            if(data.get(index).getValue() <= selected.getValue()){
                HeartRateValueEntity temporary = data.get(split);
                data.set(split, data.get(index));
                data.set(index, temporary);

                split++;
            }
        }

        quickSort(data, leftMostIndex, split - 2);
        quickSort(data, split, rightMostIndex);
    }

    private long findMedian(ArrayList<HeartRateValueEntity> sortedData, int startPosition, int endPosition){
        int size = endPosition - startPosition;
        if(size % 2 == 0) return (sortedData.get(size/2).getValue() + sortedData.get(size/2+1).getValue()) / 2;
        else return sortedData.get(size/2).getValue();
    }
}
