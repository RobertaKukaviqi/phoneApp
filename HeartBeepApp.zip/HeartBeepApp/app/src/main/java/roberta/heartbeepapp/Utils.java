package roberta.heartbeepapp;

import android.util.Log;

import org.threeten.bp.DayOfWeek;
import org.threeten.bp.LocalDate;
import org.threeten.bp.LocalDateTime;
import org.threeten.bp.format.DateTimeFormatter;
import org.threeten.bp.temporal.TemporalAdjuster;
import org.threeten.bp.temporal.TemporalAdjusters;

public class Utils {

    public static LocalDate getWeekStart(LocalDate calendar){
        LocalDate date = calendar;
        date = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        return date;
    }

    public static String timeToString(LocalDateTime time){
        return time.format(DateTimeFormatter.ofPattern("YYYY-MM-dd HH:mm:ss"));
    }


}
