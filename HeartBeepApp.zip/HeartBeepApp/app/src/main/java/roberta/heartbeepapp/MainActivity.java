package roberta.heartbeepapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;

import org.threeten.bp.LocalDate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("UserId", Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid());

        Utils.getWeekStart(LocalDate.now());

        FirebaseDatabase.getInstance().getReference("users")
                .child("phone")
                .child(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid())
                .child("name")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.getValue() != null)
                            getSupportActionBar().setTitle(dataSnapshot.getValue().toString());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

        FirebaseDatabase.getInstance().getReference("users")
                .child("phone")
                .child(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid())
                .child("wears")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Map<String, Boolean> td = (HashMap<String,Boolean>) dataSnapshot.getValue();

                        showEmptyPage(td == null || td.isEmpty());
                        if(td == null || td.isEmpty()) {
                            return;
                        }

                        ArrayList<String> wearsList = new ArrayList<>();

                        for(Map.Entry<String, Boolean> entry: td.entrySet()){
                            if(entry.getValue()){
                               wearsList.add(entry.getKey());
                            }
                        }
                        //subscribe for notification on all registered smart watches
                        for(int i = 0; i < wearsList.size(); i++){
                            FirebaseMessaging.getInstance().subscribeToTopic(wearsList.get(i));
                        }

                        initViews(wearsList);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

        FloatingActionButton addWatchBtn = findViewById(R.id.add_watch_btn);
        addWatchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddWatchActivity.class);
                startActivity(intent);
            }
        });
    }

    private void showEmptyPage(Boolean show){
        if(show) {
            findViewById(R.id.viewpager).setVisibility(View.GONE);
            findViewById(R.id.tabs).setVisibility(View.GONE);
        }else{
            findViewById(R.id.viewpager).setVisibility(View.VISIBLE);
            findViewById(R.id.tabs).setVisibility(View.VISIBLE);
        }
    }

    private void initViews(ArrayList<String> data) {
        ViewPager vp = findViewById(R.id.viewpager);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(vp);
        vp.setAdapter(new WearableViewPagerAdapter(getSupportFragmentManager(), data));

        showEmptyPage(data.size() == 0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case R.id.menu_logout:
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            break;
        }

        return super.onOptionsItemSelected(item);
    }
}
